"""
给定一个字符串
abcaabbcd  ==> a3b3c2d1

1.只允许使用items() 或 isalpha()
2.不允许使用任何函数
"""
str1 = "abcaabbcd"

dict_char = {}
for char in str1:
    if char in dict_char:
        dict_char[char] += 1 
    else:
        dict_char[char] = 1

    print(dict_char)

output_str = ""

# for char, count in dict_char.items():
for key in dict_char:
    output_str += f"{key}{dict_char[key]}"

print(output_str)
