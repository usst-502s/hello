"""
容器嵌套
"""
list_movie = [
    {
        "name": "咒怨",
        "type": ("动画", "儿童"),
        "actor": ["小孩", "女主"]
    },
    {
        "name": "灰姑娘",
        "type": ("唯美", "情节"),
        "actor": ["小美", "大漂亮"]
    }
]
# 1.打印大漂亮  下课休息 16:18继续
print(list_movie[1]["actor"][1])

# 2.打印所有电影的类型
for item in list_movie:
    # print(item["type"])
    for sub in item["type"]:
        print(sub)
