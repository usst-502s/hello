"""
颠倒字典的键和值
"""
dict1 = {
    "1001": "Beijing",
    "1002": "Tianjin",
    "1003": "Hebei",
}
dict_new = {}
for key, value in dict1.items():
    # dict_new[value] = key
    dict_new.update({value: key})

print(dict_new)
