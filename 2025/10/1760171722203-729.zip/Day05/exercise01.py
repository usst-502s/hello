"""
编写一段代码,处理字符串,得到一下结果
["apple", "orange", "banana", "pear", "grape"]
"""
# 下课休息 11:20继续
str1 = "apple,orange;_banana |   pear * & grape"

str_new = ""
for char in str1:
    if char.isalpha():
        # print(f"{char}是字母")
        str_new += char
    else:
        # print(f"{char}不是字母")
        str_new += " "

print(str_new.split())
print(str_new.split(" "))
