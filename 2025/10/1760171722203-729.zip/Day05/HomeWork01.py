"""
在终端中分别输入月和日
计算这是一年中的第几天 2月份默认29天
4月7日 98天
"""
month = int(input("请输入月份:"))
day = int(input("请输入日:"))

tuple_day = (31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)

days = day + sum(tuple_day[:month - 1])
print(days)
