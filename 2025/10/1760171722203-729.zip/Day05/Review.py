"""
列表
  推导式
  深拷贝 所有层数据独立
  浅拷贝 浅层(1层)数据独立,深层数据共享

元组
  不可变序列容器
  创建: 元组名 = () 元组名 = 元素,
  访问: 索引和切片
  遍历: for
  解包: 基础解包  *号解包
字符串
  由一系列字符的编码值组成的不可变序列容器
  创建: "" '' 三引号
  访问: 索引和切片
  遍历: for
  转义: 转义符\  \" \n  \t

"""
list1 = [[1, 2, 3], [4, 5, 6]]
print(list1)

for item in list1:
    for sub in item:
        print(sub)

tuple1 = (1, 2, 3, 4)
a, b, c, d = tuple1

tuple1 = ((1, 2, 3), (4, 5, 6))
for a, *b in tuple1:
    print(a, b)

tuple2 = ([1, 2, 3], [4, 5, 6])
tuple2[0][1] = "当然"
print(tuple2)

tuple2 = (1, 2)
print(tuple2)
