"""
字典推导式

字典名 = {键:值 for 变量 in 可迭代对象}
字典名 = {键:值 for 变量 in 可迭代对象 if 条件}
"""
dict1 = {
    "1001": "Beijing",
    "1002": "Tianjin",
    "1003": "Hebei",
}
dict_new = {}
for key, value in dict1.items():
    # dict_new[value] = key
    dict_new.update({value: key})

print(dict_new)

# 推导式写法
dict_new = {value: key for key, value in dict1.items()}
print(dict_new)
