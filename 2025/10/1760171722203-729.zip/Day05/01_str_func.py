"""
字符串函数
"""
# 替换
str1 = "CNM太菜了CNM"
print(str1.replace("CNM", "**"))
print(str1.replace("CNM", "**", 1))

# 分割 默认空格
str2 = "2025-01-01"
print(str2.split("-"))

# 拼接
list1 = ["a", "b", "c"]
print("-".join(list1))

# 查找
str3 = "Hello WorLd"
# 第一次出现的位置,找不到返回-1
print(str3.find("L"))
# 最后一次出现的位置,找不到返回-1
print(str3.rfind("l"))

# 判断相关
str4 = "Hi"
str5 = "666"
str6 = "999黑Hi"
# 纯数字
print(str6.isdigit())
print(str5.isdigit())
# 纯字母
print(str4.isalpha())
# 数字+字母
print(str5.isalnum())
print(str6.isalnum())
