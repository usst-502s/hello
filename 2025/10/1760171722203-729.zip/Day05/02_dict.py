"""
字典
由一系列键值对组成的可变散列容器
键值对: 键:值 键必须是不可变且唯一 值没限制
散列: 哈希计算 对键进行哈希计算确定存储位置
"""
dict_movie = {
    "name": 749,
    "index": 10086,
    "type": ("动画", "剧情")
}

# 2.访问
print(dict_movie["name"])
# print(dict_movie["age"]) #不存在的键报错
print(dict_movie.get("type"))  # 安全
# print(dict_movie.get("age"))  # 不存在的键返回None或指定的默认值

# 3.添加/修改
# 给字典不存在的键赋值就是添加,存在的键赋值就是修改
dict_movie["city"] = "China"
dict_movie["index"] = 10010
dict_movie.update({"index": 555, "year": 2015})

# 4.删除
del dict_movie["year"]
dict_movie.pop("index")
dict_movie.popitem()  # 最后一个
print(dict_movie)

# 5.遍历
# 默认获取键
for key in dict_movie:
    print(key, dict_movie[key])

# 获取值
for value in dict_movie.values():
    print(value)

# 获取键和值
print(dict_movie.items())
for key,value in dict_movie.items():
    print(key,value)










