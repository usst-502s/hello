"""
成员运算符

in 检查一个元素(键)在不在其中,在返回True,不在返回False
not in 检查一个元素(键) 不在其中,不在返回True,在返回False
"""
list1 = [1, 2, 3, 4]
tuple1 = (1, 2, 3, 4)
str1 = "1234"
dict1 = {"1": "PHP", "name": 2}
int1 = 1234

print(3 in list1)
print("4" not in str1)
# 看的键
print("1" in dict1)
# print(1 in int1) #报错 int类型不是可迭代的


# 比较运算
list1 = [1, 2]
list2 = [1, 2]
tuple1 = (1, 2)
tuple2 = (1, 2)
dict1 = {"1": "PHP", "name": 2}
dict2 = {"1": "PHP", "name": 2}

print(1.2 == 1.2)
print(list1 == list2)
print(tuple1 == tuple2)
print(dict1 == dict2)

"""
身份运算符

is 比较2个对象是不是同一个对象(内存地址) 是返回True,反之返回False
is not 比较2个对象不是同一个对象(内存地址) 不是返回True,反之返回False

"""
a = 10
b = 10
print(a is b)  # T

a = [1, 2, 3]
b = [1, 2, 3]
print(a is b)  # F

a = (1, 2, 3, 4)
b = (1, 2, 3, 4)
print(a is b)  # T
