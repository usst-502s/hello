"""
文件写入 文本文件

r模式  读  文件不存在报错
w模式  写  文件不存在创建 覆盖
a模式  追加写 文件不存在创建 不覆盖

"""
with open("A.txt", "w", encoding="utf-8") as file:
    file.write("like for like")

with open("A.txt", "a", encoding="utf-8") as file:
    file.write("King have long arms")
    file.writelines(["1", "2", "3"])  # 接受可迭代对象作为参数
