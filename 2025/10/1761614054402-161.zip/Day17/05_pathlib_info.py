"""
文件信息
"""
from pathlib import Path

# 1.工作路径
print(Path.cwd())

# 2.拼接
print(Path.cwd().joinpath("05_pathlib_info.py"))
print(Path.cwd() / "05_pathlib_info.py")

# 3.判断
print(Path("Demo.py").exists())  # F
print(Path("test.py").exists())  # T
print(Path("TEsT.py").exists())  # F/T 和文件系系统有关

# 4.信息
print(Path("05_pathlib_info.py").is_file())
print(Path("05_pathlib_info.py").is_dir())
print(Path("05_pathlib_info.py").name)
print(Path("05_pathlib_info.py").stem)
print(Path("05_pathlib_info.py").suffix)
print(Path("05_pathlib_info.py").stat())

times = Path("05_pathlib_info.py").stat().st_mtime
print(times)
from datetime import datetime
# 2025-10-27 11:55:49.528001
print(datetime.fromtimestamp(times))
