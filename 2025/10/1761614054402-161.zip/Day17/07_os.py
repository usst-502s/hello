"""
os库
"""
import os
import shutil

# 1.系统信息
print(F"系统:{os.name}")  # nt ->windows posix -> Linux/mac

# 2.获取进程
print(os.getpid())

# 3.目录管理
# os.mkdir("os_new")  # 单个
os.makedirs("os_new2/A/B/D/E", exist_ok=True)  # 递归创建多层级
# os.rmdir("os_new")
shutil.rmtree("os_new2")  # 递归删除

# 4.文件管理
# os.remove("A.txt")
# os.rename("A.txt","A.txt")

# 5.路径处理
path = os.path.join("a", "b", "c.txt")  # 拼接
print(path)

dir_name, file_name = os.path.split(path)  # 分割
print(dir_name, file_name)

abs_path = os.path.abspath(os.getcwd())  # 绝对路径
print(abs_path)

# 6.文件属性(和pathlib基本一致)
print(os.stat("07_os.py"))

# 7.遍历
for item in os.listdir("."):  # 当前级
    print(item)

# 递归 当前目录 子目录 文件
for root, dirs, files in os.walk(".."):
    print(root, dirs, files)
