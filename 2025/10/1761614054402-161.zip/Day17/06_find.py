"""
文件查找
"""
from pathlib import Path


# 当前
for item in Path.cwd().glob("0*"):
    print(item)

# 父级
for item in Path.cwd().parent.glob("*ay*"):
    print(item)

# 递归搜索
for item in Path.cwd().parent.rglob("*.py"):
    print(item)