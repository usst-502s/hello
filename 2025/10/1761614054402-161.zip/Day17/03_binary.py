"""
二进制文件-读取

路径:
  绝对路径:从根目录开始,逐级到目标文件或目录的完整路径
    windows: 以驱动器字母开始 C:/user/app
    Linux/unix: 以 / 开头 /usr/bin
  相对路径:相对于一个位置表述
  . 当前目录
  .. 父级目录
"""
with open("../Day16/内存图.png", "rb") as file:
    # print(file.read())  # b'\x89PNG\r\n\x1a\n... 字节对象
    # 验证是不是标准的png文件 前8个 --> 标准PNG文件头
    print(file.read(8))
