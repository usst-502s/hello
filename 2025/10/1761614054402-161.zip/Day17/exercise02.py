"""
找到AIDTN2509目录内(以自己的为主)
所有.py文本文件的大小,使用列表存储
格式:["990.00B","1.2KB","22.3MB","2200.3MB"]
1KB = 1024B
1MB = 1024KB

"""
from pathlib import Path


def calc_size(size):
    units = ["B", "KB", "MB"]
    for unit in units:
        # size小于1024没必要计算
        if size < 1024 or unit == units[-1]:
            return f"{size:.2f}{unit}"

        size /= 1024


'''
测试代码:
print(calc_size(100))
print(calc_size(6236))
print(calc_size(1520063))
print(calc_size(2354651522))
'''

list_size = []
for item in Path.cwd().parent.rglob("*.py"):
    size = item.stat().st_size
    format_size = calc_size(size)
    list_size.append(format_size)

print(list_size)

# 高阶函数
print(
    list(
        map(
            lambda item: calc_size(item.stat().st_size),
            Path.cwd().parent.rglob("*.py")
        )
    )
)

# 列表推导式
print([calc_size(item.stat().st_size) for item in Path.cwd().parent.rglob("*.py")])
