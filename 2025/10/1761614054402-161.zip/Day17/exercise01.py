"""
找到AIDTN2509目录内(以自己的为主)
所有.txt文本文件的 mtime 并打印
格式:2025年10月27日 14点15分35秒
"""
from pathlib import Path
from datetime import datetime

for item in Path.cwd().parent.rglob('*.txt'):
    print(
        datetime.fromtimestamp(item.stat().st_mtime)
            .strftime("%Y年%m月%d日 %H时%M分%S秒")
    )
