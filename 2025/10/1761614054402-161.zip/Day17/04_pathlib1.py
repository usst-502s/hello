"""
文件/目录操作
"""
from pathlib import Path

# 创建
# 文件
Path("xiaoyi.txt").touch()
# 目录
Path("test").mkdir(exist_ok=True)
Path("A/B/C/D").mkdir(exist_ok=True, parents=True)

# 删除
'''
Path("xiaoyi.txt").unlink()
Path("test").rmdir()
# Path("A").rmdir() #不能删除非空的目录
'''

# 重命名
# Path("xiaoyi.txt").rename("xiaoyi.txt")
Path("xiaoyi.txt").rename("A/B/xiaoyi.txt")
Path("A/B").rename("A/Has")
