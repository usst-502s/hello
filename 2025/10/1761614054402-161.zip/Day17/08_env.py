"""
环境变量 安全

根据不同的场景选择不同的配置
避免api ak sk 硬编码在代码中
处理不同操作系统的文件路径差异
"""
import os
import json

# 模拟API的数据
test_data = {
    "users": [
        {"id": 1, "name": "测试用户"}
    ]
}
prod_data = {
    "users": [
        {"id": 1, "name": "生产用户"}
    ]
}

# 创建模拟数据json
with open("test.json", "w") as file:
    # 数据转成json字符串写入json文件
    json.dump(test_data, file)

with open("prod.json", "w") as file:
    json.dump(prod_data, file)

# 模拟环境变量(.env/.yaml来控制)
os.environ["APP_ENV"] = "PROD"
os.environ["APP_DATA_PATH"] = F"{os.path.join(os.getcwd(), 'test.json')}"

# 模拟根据环境变量加载配置
app_env = os.environ.get("APP_ENV", "TEST")
data_path = os.environ.get("APP_DATA_PATH", "")

# 模拟API响应
if app_env == "TEST":
    with open(data_path) as file:
        data = json.load(file)
        print(f"测试数据:{data}")
elif app_env == "PROD":
    data_path = "prod.json"
    with open(data_path) as file:
        data = json.load(file)
        print(f"生产数据:{data}")
