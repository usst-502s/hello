import random
import sys
import os
from PyQt5 import QtWidgets, QtGui, QtCore
from PyQt5.QtWidgets import QApplication, QCheckBox, QPushButton, QHBoxLayout, QVBoxLayout, QLabel, QLineEdit, QWidget, \
    QHeaderView, QTableWidgetItem, QDialog, QDialogButtonBox, QFileDialog, QMessageBox

from PyQt5.QtCore import Qt, QPoint
from datetime import datetime
import uuid

DEFAULT_IMAGE_PATH = "../../source/images/goods/default.png"


def get_next_id(data_list):
    """生成唯一递增ID"""
    if not data_list:
        return 1
    ids = [int(item[0]) for item in data_list]
    return max(ids) + 1


# 图片显示类
class HoverLabel(QtWidgets.QLabel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.fullsize_label = QtWidgets.QLabel()
        self.fullsize_label.setWindowFlag(Qt.ToolTip)

        # 内容缩放
        self.fullsize_label.setScaledContents(True)
        # 事件过滤器
        self.installEventFilter(self)

    # 事件过滤器(重写)
    def eventFilter(self, obj, event):
        # Enter鼠标进入事件
        if event.type() == QtCore.QEvent.Enter:
            pixmap = QtGui.QPixmap(self.property("full_image_path"))

            if not pixmap.isNull():
                self.fullsize_label.setPixmap(pixmap.scaled(400, 400))
                # 获取属鼠标的位置，把图片显示在鼠标位置的右下方(偏移)
                pos = QtGui.QCursor.pos() + QPoint(20, 20)
                print('pos', pos)
                self.fullsize_label.move(pos)
                self.fullsize_label.show()

        # 鼠标离开
        elif event.type() == QtCore.QEvent.Leave:
            self.fullsize_label.hide()

        return super().eventFilter(obj, event)


class Page1Widget(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.setupUi()
        self.dataList = []
        self.initTable()

    # 布局
    def setupUi(self):
        self.resize(1500, 900)
        # 整体垂直布局
        self.verticalLayout = QtWidgets.QVBoxLayout(self)
        # 间距
        self.verticalLayout.setContentsMargins(20, 20, 20, 20)
        self.verticalLayout.setSpacing(15)

        # 顶部操作栏
        self.top_widget = QtWidgets.QWidget()

        # 给指定的容器部件设置布局
        self.top_layout = QtWidgets.QHBoxLayout(self.top_widget)
        self.title_Label = QtWidgets.QLabel("商品列表")
        self.title_Label.setStyleSheet("font: bold 16pt 'Microsoft YaHei UI'; color:#2c3e50;")
        self.top_layout.addWidget(self.title_Label)

        self.top_layout.addStretch()

        self.add_btn = QPushButton("添加商品")
        self.add_btn.setFixedSize(120, 40)
        self.add_btn.setStyleSheet(self.get_btn_style("#2ecc71"))
        self.top_layout.addWidget(self.add_btn)
        self.add_btn.clicked.connect(self.show_add_dialog)

        self.batch_del_btn = QPushButton("批量删除")
        self.batch_del_btn.setFixedSize(120, 40)
        self.batch_del_btn.setStyleSheet(self.get_btn_style("orange"))
        self.top_layout.addWidget(self.batch_del_btn)
        self.batch_del_btn.clicked.connect(self.on_batch_delete)

        # 把水平布局添加到大的垂直布局中来
        self.verticalLayout.addWidget(self.top_widget)

        # 表格区域
        self.table_widget = QtWidgets.QTableWidget()
        self.verticalLayout.addWidget(self.table_widget)

    # 表格
    def initTable(self):
        headers = ["选择", "商品编号", "商品标题", "商品图片", "价格(元)", "库存数量", "SKU", "SPU", "操作"]
        # 设置列数
        self.table_widget.setColumnCount(len(headers))
        # 设置表头
        self.table_widget.setHorizontalHeaderLabels(headers)
        # 自适应列宽
        self.table_widget.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        # 禁止编辑
        self.table_widget.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        # 隐藏垂直表头
        self.table_widget.verticalHeader().setVisible(False)
        # 交替行变色
        self.table_widget.setAlternatingRowColors(True)

        # 初始化数据 行数
        for data in self.dataList:
            self.add_table_row(data)

    # 添加数据 【填写逻辑】
    def add_table_row(self, data):
        pass

    # 商品单个删除（通过ID删除）【填写逻辑】
    def delete_row(self, item_id):
        pass

    # 批量删除商品【填写逻辑】
    def on_batch_delete(self):
        pass

    # 图片显示
    def set_image_cell(self, row, col, image_path):
        print(image_path)
        label = HoverLabel()
        # 把图片路径存储为标签属性
        label.setProperty("full_image_path", image_path)

        if os.path.exists(image_path):
            # QPixmap 处理图像的类
            pixmap = QtGui.QPixmap(image_path)
        else:
            pixmap = QtGui.QPixmap(DEFAULT_IMAGE_PATH)

        label.setPixmap(pixmap.scaled(120, 120))
        label.setAlignment(Qt.AlignCenter)
        self.table_widget.setCellWidget(row, col, label)

    # 按钮公共样式
    def get_btn_style(self, color):
        # 控件 {属性: 属性值}   QPushButton {color:white;}
        return f"""
            QPushButton {{
                background:{color};
                color:white;
                border-radius:5px;
                border:none;
            }} 
            QPushButton:hover {{ background: {self.adjust_color(color, -20)};}}   
            QPushButton:pressed {{ background: {self.adjust_color(color, -40)};}}   
        """

    # 调整颜色
    def adjust_color(self, color, amount):
        # 把16进制颜色 #FF001C 转换成QT的QColor对象
        color_obj = QtGui.QColor(color)
        # 调整颜色亮度 >127越来越亮 <=127越来越暗
        # name: a把QColor对象转换成16进制颜色 #FF001C
        return color_obj.lighter(100 + amount).name()

    # 添加商品弹窗【填写逻辑】
    def show_add_dialog(self):
        pass

    # 修改商品弹窗（通过ID修改） 【填写逻辑】
    def show_edit_dialog(self, item_id):
        pass


class ProductDialog(QDialog):
    def __init__(self, parent=None, data=None):
        super().__init__(parent)
        self.setWindowTitle("添加商品" if not data else "编辑商品")
        self.setFixedSize(500, 500)
        self.image_path = data[2] if data else DEFAULT_IMAGE_PATH

        layout = QVBoxLayout()
        layout.setContentsMargins(20, 20, 20, 20)

        # 标题
        self.title_prd = QLabel("商品标题")
        self.title_edit = QLineEdit(data[1] if data else "")
        self.title_edit.setPlaceholderText("请输入商品标题")
        layout.addWidget(self.title_prd)
        layout.addWidget(self.title_edit)

        # 价格
        self.price_prd = QLabel("商品价格")
        self.price_edit = QLineEdit(data[3] if data else "")
        self.price_edit.setPlaceholderText("请输入商品价格")
        layout.addWidget(self.price_prd)
        layout.addWidget(self.price_edit)

        # 图片上传
        self.image_label = QtWidgets.QLabel()
        self.image_label.setFixedSize(200, 200)
        self.update_image()

        layout.addWidget(QLabel("商品图片："))
        layout.addWidget(self.image_label)

        btn_upload = QPushButton("上传图片")
        btn_upload.clicked.connect(self.upload_image)
        layout.addWidget(btn_upload)

        # 按钮组
        btn_box = QDialogButtonBox(QDialogButtonBox.Cancel | QDialogButtonBox.Ok)
        btn_box.rejected.connect(self.reject)
        btn_box.accepted.connect(self.accept)
        layout.addWidget(btn_box)
        self.setLayout(layout)

    # 上传图片【填写逻辑】
    def upload_image(self):
        pass

    def update_image(self):
        # 图片回显
        pixmap = QtGui.QPixmap(self.image_path)

        if pixmap.isNull():
            pixmap = QtGui.QPixmap(DEFAULT_IMAGE_PATH)

        self.image_label.setPixmap(pixmap.scaled(180, 180))


if __name__ == "__main__":
    APP = QApplication(sys.argv)
    window = Page1Widget()
    window.show()
    sys.exit(APP.exec())
