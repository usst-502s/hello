# coding =utf-8
from PyQt5 import QtWidgets
import sys
import os
from PyQt5 import uic

page5_UI = uic.loadUiType(os.path.join("ui/page/system.ui"))[0]

class Page5_UI_Widget(QtWidgets.QWidget, page5_UI):
    '''
    中间内容区域的第一页模板
    '''
    def __init__(self,  *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setupUi(self)
        self.initUi()

    def initUi(self):
        '''
        初始化表单
        '''

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    main = QtWidgets.QFrame()
    win = Page5_UI_Widget(main)
    main.show()
    sys.exit(app.exec_())