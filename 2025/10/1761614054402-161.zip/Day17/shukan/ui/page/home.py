# coding =utf-8
from PyQt5 import QtWidgets
import os
from PyQt5 import uic
from PyQt5.QtWidgets import QTableWidgetItem, QHeaderView, QLabel

from PyQt5.QtCore import Qt

page3_UI = uic.loadUiType(os.path.join("ui/page/home.ui"))[0]


class Page3_UI_Widget(QtWidgets.QWidget, page3_UI):
    '''
    中间内容区域的第一页模板
    '''

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setupUi(self)
        self.initUi()
        self.initChart1()
        self.initChart2()

    def initUi(self):
        '''
        初始化表单
        '''
        self.p3_wg1_title_label.setProperty('class', 'p3_item_label_title')
        self.p3_wg3_title_label.setProperty('class', 'p3_item_label_title')

        self.p3_wg2_gl_1_1_label1.setProperty('class', 'p3_wg2_item_label_value')
        self.p3_wg2_gl_1_1_label2.setProperty('class', 'p3_wg2_item_label_name')
        self.p3_wg2_gl_1_1_label3.setProperty('class', 'p3_wg2_item_label_remark')

        self.p3_wg2_gl_1_2_label1.setProperty('class', 'p3_wg2_item_label_value')
        self.p3_wg2_gl_1_2_label2.setProperty('class', 'p3_wg2_item_label_name')
        self.p3_wg2_gl_1_2_label3.setProperty('class', 'p3_wg2_item_label_remark')

        self.p3_wg2_gl_1_3_label1.setProperty('class', 'p3_wg2_item_label_value')
        self.p3_wg2_gl_1_3_label2.setProperty('class', 'p3_wg2_item_label_name')
        self.p3_wg2_gl_1_3_label3.setProperty('class', 'p3_wg2_item_label_remark')

        self.p3_wg2_gl_2_1_label1.setProperty('class', 'p3_wg2_item_label_value')
        self.p3_wg2_gl_2_1_label2.setProperty('class', 'p3_wg2_item_label_name')
        self.p3_wg2_gl_2_1_label3.setProperty('class', 'p3_wg2_item_label_remark')

        self.p3_wg2_gl_2_2_label1.setProperty('class', 'p3_wg2_item_label_value')
        self.p3_wg2_gl_2_2_label2.setProperty('class', 'p3_wg2_item_label_name')
        self.p3_wg2_gl_2_2_label3.setProperty('class', 'p3_wg2_item_label_remark')

        self.p3_wg2_gl_2_3_label1.setProperty('class', 'p3_wg2_item_label_value')
        self.p3_wg2_gl_2_3_label2.setProperty('class', 'p3_wg2_item_label_name')
        self.p3_wg2_gl_2_3_label3.setProperty('class', 'p3_wg2_item_label_remark')

    def set_column_width_percentage(self, table_widget, column, percentage):
        total_width = table_widget.viewport().width()
        column_width = int(total_width * (percentage / 100))
        table_widget.setColumnWidth(column, column_width)

    def resizeEvent1(self, event):
        self.set_column_width_percentage(self.p3_wg5_wg_left_tableWidget, 0, 10)  # 设置第一列宽度为50%
        self.set_column_width_percentage(self.p3_wg5_wg_left_tableWidget, 1, 30)  # 设置第二列宽度为30%
        self.set_column_width_percentage(self.p3_wg5_wg_left_tableWidget, 2, 30)  # 设置第三列宽度为20%
        self.set_column_width_percentage(self.p3_wg5_wg_left_tableWidget, 3, 30)  # 设置第三列宽度为20%

    def resizeEvent2(self, event):
        self.set_column_width_percentage(self.p3_wg5_wg_right_tableWidget, 0, 10)  # 设置第一列宽度为50%
        self.set_column_width_percentage(self.p3_wg5_wg_right_tableWidget, 1, 30)  # 设置第二列宽度为30%
        self.set_column_width_percentage(self.p3_wg5_wg_right_tableWidget, 2, 30)  # 设置第三列宽度为20%
        self.set_column_width_percentage(self.p3_wg5_wg_right_tableWidget, 3, 30)  # 设置第三列宽度为20%

    def addTableRow(self, table, row_data):
        '''
        添加行数据
        '''
        # 功能： 在末尾添加新行
        row = table.rowCount()
        table.setRowCount(row + 1)
        col = 0
        for item in row_data:
            if col == 0:
                label = QLabel(str(item))
                if row == 0:
                    label.setProperty('class', 'page1_QLabel1')
                elif row == 1:
                    label.setProperty('class', 'page1_QLabel2')
                elif row == 2:
                    label.setProperty('class', 'page1_QLabel3')
                else:
                    label.setProperty('class', 'page1_QLabel4')

                label.setAlignment(Qt.AlignCenter)
                table.setCellWidget(row, col, label)
            else:
                cell = QTableWidgetItem(str(item))
                table.setItem(row, col, cell)
                table.item(row, col).setTextAlignment(Qt.AlignCenter)
            col += 1

    def initChart1(self):
        '''
        创建图表1
        '''
        self.p3_wg5_wg_left_tableWidget.setProperty('class', 'page1_QTableWidget')

        headerList = ['排行', '商品代码', '商品名称', '商品类别']
        dataList = [
            ['No1', '维达卫生纸', '个护', "1869530"],
            ['No2', 'Dior戴妃', '箱包', "1152630"],
            ['No3', '赫莲娜晚面霜', '美妆', "986536"],
            ['No4', 'SKII精华液', '美妆', "902623"],
            ['No5', '鲜活大闸蟹', '生鲜', "756952"],
            ['No6', '滴露消毒液', '个护', "625341"],
            ['No7', '拯救者游戏本', '电脑', "562315"],
            ['No8', '海尔洗烘一体机', '家电', "354621"]
        ]
        # 设置列数量
        self.p3_wg5_wg_left_tableWidget.setColumnCount(len(headerList));
        # 设置表头
        self.p3_wg5_wg_left_tableWidget.setHorizontalHeaderLabels(headerList)

        self.p3_wg5_wg_left_tableWidget.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        # 设置隔行变色
        self.p3_wg5_wg_left_tableWidget.setAlternatingRowColors(True)
        # 设置固定行高
        self.p3_wg5_wg_left_tableWidget.verticalHeader().setSectionResizeMode(QHeaderView.Fixed)
        # 设置行高
        self.p3_wg5_wg_left_tableWidget.verticalHeader().setDefaultSectionSize(40)

        # 添加行内容
        for row in dataList:
            self.addTableRow(self.p3_wg5_wg_left_tableWidget, row)

        self.p3_wg5_wg_left_tableWidget.resizeEvent = self.resizeEvent1

    def initChart2(self):
        '''
        创建图表2
        '''
        self.p3_wg5_wg_right_tableWidget.setProperty('class', 'page1_QTableWidget')

        headerList = ['排行', '会员编号', '会员名称', '订单金额(元)']
        dataList = [
            ['No1', '吃土豆的马铃薯', '15623', '784121'],
            ['No2', '在逃公主', '895621', '633451'],
            ['No3', '晚晚', '45623', '618263'],
            ['No4', '阿尔温莉', '1489562', '531386'],
            ['No5', '不吃香菜', '75623', '412197'],
            ['No6', '徐静怡同学', '426648', '317396'],
            ['No7', '小兔团儿', '98234', '297151'],
            ['No8', '疆疆好', '56365', '165361']
        ]
        # 设置列数量
        self.p3_wg5_wg_right_tableWidget.setColumnCount(len(headerList));
        # 设置表头
        self.p3_wg5_wg_right_tableWidget.setHorizontalHeaderLabels(headerList)

        self.p3_wg5_wg_right_tableWidget.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        # 设置隔行变色
        self.p3_wg5_wg_right_tableWidget.setAlternatingRowColors(True)
        # 设置固定行高
        self.p3_wg5_wg_right_tableWidget.verticalHeader().setSectionResizeMode(QHeaderView.Fixed)
        # 设置行高
        self.p3_wg5_wg_right_tableWidget.verticalHeader().setDefaultSectionSize(40)

        # 添加行内容
        for row in dataList:
            self.addTableRow(self.p3_wg5_wg_right_tableWidget, row)

        self.p3_wg5_wg_right_tableWidget.resizeEvent = self.resizeEvent2
