import os.path

from PyQt5 import QtWidgets
from PyQt5.QtCore import QFile, QTextStream
from PyQt5.QtWidgets import QMainWindow
from PyQt5 import uic
import qtawesome

from ui.login.reg_ui import RegDialog
from ui.page.list import Page1Widget
from ui.page.manage import Page2_UI_Widget
from ui.page.home import Page3_UI_Widget
from ui.page.charts import Page4_UI_Widget
from ui.page.system import Page5_UI_Widget

Ui_MainWindow = uic.loadUiType(os.path.join("ui/layout/layout.ui"))[0]


class Main_Window(QMainWindow, Ui_MainWindow):

    def __init__(self, *args):
        super().__init__(*args)
        self.setupUi(self)
        self.setWindowTitle("数瞰商智运营系统")
        self.initQSS()
        self.init_left_menu()
        self.init_right_page()
        self.init_top_menu()

    def initQSS(self):
        style_file = QFile(os.path.join("source/style/style.qss"))
        if style_file.open(QFile.ReadOnly | QFile.Text):
            stream = QTextStream(style_file)
            style_sheet = stream.readAll()
            self.setStyleSheet(style_sheet)

    def init_top_menu(self):
        self.top_toolButton1.clicked.connect(lambda: self.on_showpage_clicked(0))
        self.top_toolButton2.clicked.connect(lambda: self.on_showpage_clicked(4))
        self.top_toolButton3.clicked.connect(self.on_reg_clicked)
        self.top_toolButton4.clicked.connect(self.on_exit_clicked)

    def init_right_page(self):
        self.page3_UI_Widget = Page3_UI_Widget()
        self.page1_right_st_horizontalLayout.addWidget(self.page3_UI_Widget)
        self.Page1Widget = Page1Widget()
        self.page2_right_st_horizontalLayout.addWidget(self.Page1Widget)
        self.page2_UI_Widget = Page2_UI_Widget()
        self.page3_right_st_horizontalLayout.addWidget(self.page2_UI_Widget)
        self.page4_UI_Widget = Page4_UI_Widget()
        self.page4_right_st_horizontalLayout.addWidget(self.page4_UI_Widget)
        self.page5_UI_Widget = Page5_UI_Widget()
        self.page5_right_st_horizontalLayout.addWidget(self.page5_UI_Widget)

        self.setStackCurrentPage(0)

    def init_left_menu(self):

        rows = 20
        columns = 1
        # 设置行和列的拉伸系数
        for row in range(rows):
            self.left_widget_gridLayout.setRowStretch(row, 1)
        for column in range(columns):
            self.left_widget_gridLayout.setColumnStretch(column, 1)

        # 第1子栏目菜单
        self.left_button_subtitle_1 = QtWidgets.QPushButton("商品管理")
        self.left_button_subtitle_1.setObjectName('left_button_subtitle')
        self.left_button_1_1 = QtWidgets.QPushButton(qtawesome.icon('fa5s.list', color='#333'), "商品列表")
        self.left_button_1_1.setObjectName('left_button')
        self.left_button_1_2 = QtWidgets.QPushButton(qtawesome.icon('fa5b.telegram-plane', color='#333'), "商品发布")
        self.left_button_1_2.setObjectName('left_button')
        self.left_button_1_3 = QtWidgets.QPushButton(qtawesome.icon('fa5s.th', color='#333'), "商品分类")
        self.left_button_1_3.setObjectName('left_button')
        self.left_button_1_4 = QtWidgets.QPushButton(qtawesome.icon('mdi.warehouse', color='#333'), "商品库存")
        self.left_button_1_4.setObjectName('left_button')

        # self.left_frame_gridLayout来自ui文件里设置的名称
        self.left_widget_gridLayout.addWidget(self.left_button_subtitle_1, 0, 0, 1, 1)
        self.left_widget_gridLayout.addWidget(self.left_button_1_1, 1, 0, 1, 1)
        self.left_widget_gridLayout.addWidget(self.left_button_1_2, 2, 0, 1, 1)
        self.left_widget_gridLayout.addWidget(self.left_button_1_3, 3, 0, 1, 1)
        self.left_widget_gridLayout.addWidget(self.left_button_1_4, 4, 0, 1, 1)

        self.left_button_1_1.clicked.connect(lambda: self.on_showpage_clicked(1))
        self.left_button_1_2.clicked.connect(lambda: self.on_showpage_clicked(2))

        # 第2子栏目菜单
        self.left_button_subtitle_2 = QtWidgets.QPushButton("订单管理")
        self.left_button_subtitle_2.setObjectName('left_button_subtitle')
        self.left_button_2_1 = QtWidgets.QPushButton(qtawesome.icon('fa5s.list', color='#333'), "订单列表")
        self.left_button_2_1.setObjectName('left_button')
        self.left_button_2_2 = QtWidgets.QPushButton(qtawesome.icon('mdi6.truck-cargo-container', color='#333'),"物流追踪")
        self.left_button_2_2.setObjectName('left_button')
        self.left_button_2_3 = QtWidgets.QPushButton(qtawesome.icon('fa5s.file-invoice', color='#333'), "订单发票")
        self.left_button_2_3.setObjectName('left_button')
        # self.left_frame_gridLayout来自ui文件里设置的名称
        self.left_widget_gridLayout.addWidget(self.left_button_subtitle_2, 5, 0, 1, 1)
        self.left_widget_gridLayout.addWidget(self.left_button_2_1, 6, 0, 1, 1)
        self.left_widget_gridLayout.addWidget(self.left_button_2_2, 7, 0, 1, 1)
        self.left_widget_gridLayout.addWidget(self.left_button_2_3, 8, 0, 1, 1)

        # 第3子栏目菜单
        self.left_button_subtitle_3 = QtWidgets.QPushButton("用户管理")
        self.left_button_subtitle_3.setObjectName('left_button_subtitle')
        self.left_button_3_1 = QtWidgets.QPushButton(qtawesome.icon('fa5s.list', color='#333'), "用户列表")
        self.left_button_3_1.setObjectName('left_button')
        self.left_button_3_2 = QtWidgets.QPushButton(qtawesome.icon('ri.vip-crown-2-line', color='#333'), "会员体系")
        self.left_button_3_2.setObjectName('left_button')
        # self.left_frame_gridLayout来自ui文件里设置的名称
        self.left_widget_gridLayout.addWidget(self.left_button_subtitle_3, 9, 0, 1, 1)
        self.left_widget_gridLayout.addWidget(self.left_button_3_1, 10, 0, 1, 1)
        self.left_widget_gridLayout.addWidget(self.left_button_3_2, 11, 0, 1, 1)

        # 第4子栏目菜单
        self.left_button_subtitle_4 = QtWidgets.QPushButton("系统管理")
        self.left_button_subtitle_4.setObjectName('left_button_subtitle')
        self.left_button_4_1 = QtWidgets.QPushButton(qtawesome.icon('mdi.shield-key-outline', color='#333'), "权限管理")
        self.left_button_4_1.setObjectName('left_button')
        self.left_button_4_2 = QtWidgets.QPushButton(qtawesome.icon('fa5s.user-friends', color='#333'), "客户管理")
        self.left_button_4_2.setObjectName('left_button')
        self.left_button_4_3 = QtWidgets.QPushButton(qtawesome.icon('ri.file-list-3-fill', color='#333'), "日志管理")
        self.left_button_4_3.setObjectName('left_button')
        # self.left_frame_gridLayout来自ui文件里设置的名称
        self.left_widget_gridLayout.addWidget(self.left_button_subtitle_4, 12, 0, 1, 1)
        self.left_widget_gridLayout.addWidget(self.left_button_4_1, 13, 0, 1, 1)
        self.left_widget_gridLayout.addWidget(self.left_button_4_2, 14, 0, 1, 1)
        self.left_widget_gridLayout.addWidget(self.left_button_4_3, 15, 0, 1, 1)

        # 第5子栏目菜单
        self.left_button_subtitle_5 = QtWidgets.QPushButton("统计信息")
        self.left_button_subtitle_5.setObjectName('left_button_subtitle')
        self.left_button_5_1 = QtWidgets.QPushButton(qtawesome.icon('fa5s.comment-dots', color='#333'), "销售统计")
        self.left_button_5_1.setObjectName('left_button')
        # self.left_frame_gridLayout来自ui文件里设置的名称
        self.left_widget_gridLayout.addWidget(self.left_button_subtitle_5, 16, 0, 1, 1)
        self.left_widget_gridLayout.addWidget(self.left_button_5_1, 17, 0, 1, 1)

        self.left_button_5_1.clicked.connect(lambda: self.on_showpage_clicked(3))

    def setStackCurrentPage(self, index):
        '''
        切换QStackedWidget控件中的Page
        :return:
        '''
        widget = self.right_stackedWidget.widget(index)
        self.right_stackedWidget.setCurrentWidget(widget)

    def on_showpage_clicked(self, index):
        self.setStackCurrentPage(index)

    def on_reg_clicked(self):
        '''
        帐号设置事件响应
        '''
        reg_dialog = RegDialog(self)
        reg_dialog.open()

    def on_exit_clicked(self):
        self.close()
