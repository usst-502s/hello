from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_LoginMain(object):
    def setupUi(self, LoginMain):
        LoginMain.setObjectName("LoginMain")
        LoginMain.resize(1200, 600)
        self.login_widget = QtWidgets.QWidget(LoginMain)
        self.login_widget.setGeometry(QtCore.QRect(0, 0, 1200, 600))
        self.login_widget.setStyleSheet("#login_widget {\n"
"background-image: url(:/images/login.jpg);\n"
"background-size;cover;\n"
"}")
        self.login_widget.setObjectName("login_widget")
        self.acclogin_btn = QtWidgets.QPushButton(self.login_widget)
        self.acclogin_btn.setGeometry(QtCore.QRect(940, 20, 111, 41))
        self.acclogin_btn.setStyleSheet("font-size:14px;\n"
"border:none;\n"
"background-color: rgb(0, 170, 127);\n"
"color:white;\n"
"border-radius:15px;")
        self.acclogin_btn.setObjectName("acclogin_btn")
        self.facelogin_btn = QtWidgets.QPushButton(self.login_widget)
        self.facelogin_btn.setGeometry(QtCore.QRect(1060, 20, 111, 41))
        self.facelogin_btn.setStyleSheet("font-size:14px;\n"
"border:none;\n"
"background-color: rgb(0, 170, 127);\n"
"color:white;\n"
"border-radius:15px;")
        self.facelogin_btn.setObjectName("facelogin_btn")
        self.login_box = QtWidgets.QWidget(self.login_widget)
        self.login_box.setGeometry(QtCore.QRect(360, 100, 500, 400))
        self.login_box.setStyleSheet("#login_box{\n"
"background-color: rgba(220, 220, 220,0.5);\n"
"border-radius:20px;\n"
"}")
        self.login_box.setObjectName("login_box")
        self.login_user_label = QtWidgets.QLabel(self.login_box)
        self.login_user_label.setGeometry(QtCore.QRect(180, 10, 171, 41))
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.login_user_label.sizePolicy().hasHeightForWidth())
        self.login_user_label.setSizePolicy(sizePolicy)
        self.login_user_label.setStyleSheet("#login_user_label {\n"
"font-family: \"Noto Sans CJK SC\", \"WenQuanYi Zen Hei\", \"Droid Sans Fallback\", sans-serif;\n"
"font-size: 40px;\n"
"font-weight: bold; \n"
"    color: rgb(255, 85, 127);}\n"
"")
        self.login_user_label.setObjectName("login_user_label")
        self.user_line = QtWidgets.QLineEdit(self.login_box)
        self.user_line.setGeometry(QtCore.QRect(80, 70, 340, 70))
        font = QtGui.QFont()
        font.setFamily("Segoe UI,PingFang SC,sans-serif")
        font.setPointSize(-1)
        self.user_line.setFont(font)
        self.user_line.setStyleSheet("QLineEdit {\n"
"    font-family: \"Segoe UI\", \"PingFang SC\", sans-serif;\n"
"    font-size: 14px;\n"
"    border-radius: 10px;\n"
"    padding: 8px 12px;\n"
"    margin-bottom: 15px;\n"
"    background-color: rgba(255, 172, 194,0.7);\n"
"border:none;\n"
"outline:none;\n"
"}\n"
"\n"
"/* 输入框获得焦点时的样式 */\n"
"QLineEdit:focus {\n"
"    border: 1px solid #4d90fe;  /* 蓝色边框 */\n"
"    background-color: white;\n"
"}")
        self.user_line.setText("")
        self.user_line.setObjectName("user_line")
        self.pwd_line = QtWidgets.QLineEdit(self.login_box)
        self.pwd_line.setGeometry(QtCore.QRect(80, 180, 340, 70))
        font = QtGui.QFont()
        font.setFamily("Segoe UI,PingFang SC,sans-serif")
        font.setPointSize(-1)
        self.pwd_line.setFont(font)
        self.pwd_line.setStyleSheet("QLineEdit {\n"
"    font-family: \"Segoe UI\", \"PingFang SC\", sans-serif;\n"
"    font-size: 14px;\n"
"    border-radius: 10px;\n"
"    padding: 8px 12px;\n"
"    margin-bottom: 15px;\n"
"    background-color: rgba(255, 172, 194,0.7);\n"
"border:none;\n"
"outline:none;\n"
"}\n"
"\n"
"/* 输入框获得焦点时的样式 */\n"
"QLineEdit:focus {\n"
"    border: 1px solid #4d90fe;  /* 蓝色边框 */\n"
"    background-color: white;\n"
"}")
        self.pwd_line.setObjectName("pwd_line")
        self.login_btn = QtWidgets.QPushButton(self.login_box)
        self.login_btn.setGeometry(QtCore.QRect(80, 270, 340, 70))
        self.login_btn.setStyleSheet("#login_btn {\n"
"    \n"
"    font-family: \"Microsoft YaHei\", \"PingFang SC\", sans-serif;\n"
"    font-size: 16px;\n"
"    font-weight: bold;\n"
"    color: white;\n"
"    background-color: rgb(85, 170, 127);\n"
"    border: none;\n"
"    border-radius: 10px;\n"
"    padding: 10px;\n"
"    margin-top: 10px;\n"
"}\n"
"\n"
"/* 鼠标悬停效果 */\n"
"#login_btn:hover {\n"
"    background-color: #45a049;  /* 深绿色 */\n"
"}\n"
"\n"
"/* 按钮按下效果 */\n"
"#login_btn:pressed {\n"
"    background-color: #3e8e41;\n"
"}")
        self.login_btn.setObjectName("login_btn")
        self.login_box.raise_()
        self.acclogin_btn.raise_()
        self.facelogin_btn.raise_()

        self.retranslateUi(LoginMain)
        QtCore.QMetaObject.connectSlotsByName(LoginMain)

    def retranslateUi(self, LoginMain):
        _translate = QtCore.QCoreApplication.translate
        LoginMain.setWindowTitle(_translate("LoginMain", "数瞰商智运营系统"))
        self.acclogin_btn.setText(_translate("LoginMain", "账号密码登录"))
        self.facelogin_btn.setText(_translate("LoginMain", "人脸登录"))
        self.login_user_label.setText(_translate("LoginMain", "用户登录"))
        self.user_line.setPlaceholderText(_translate("LoginMain", "用户名"))
        self.pwd_line.setPlaceholderText(_translate("LoginMain", "用户名密码"))
        self.login_btn.setText(_translate("LoginMain", "登录"))

import modules.login_rc
