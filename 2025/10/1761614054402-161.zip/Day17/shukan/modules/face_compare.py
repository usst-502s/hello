import os
import cv2
import base64
import logging
from huaweicloudsdkcore.auth.credentials import BasicCredentials
from huaweicloudsdkcore.exceptions import exceptions
from huaweicloudsdkfrs.v2.region.frs_region import FrsRegion
from huaweicloudsdkfrs.v2 import *

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# 华为云配置
AK = os.getenv("HUAWEICLOUD_SDK_AK","自己的AK")
SK = os.getenv("HUAWEICLOUD_SDK_SK","自己的SK")
PROJECT_ID = "自己的项目ID"
REGION = "cn-north-4"

credentials = BasicCredentials(AK, SK).with_project_id(PROJECT_ID)


def validate_face_image(image_path):
    """验证图片是否包含有效人脸"""
    try:
        img = cv2.imread(image_path)
        if img is None:
            raise ValueError("无效的图片文件")

        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        face_cascade = cv2.CascadeClassifier(
            cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
        faces = face_cascade.detectMultiScale(gray, 1.1, 4)

        if len(faces) == 0:
            raise ValueError("未检测到人脸")
        if len(faces) > 1:
            raise ValueError("检测到多张人脸")

        return True
    except Exception as e:
        logger.error(f"图片验证失败: {str(e)}")
        raise


def compare_face(face1_path, face2_path):
    """人脸比对函数"""
    try:
        # 验证文件存在
        if not all(map(os.path.isfile, [face1_path, face2_path])):
            raise FileNotFoundError("人脸图片文件不存在")

        # 验证图片有效性
        validate_face_image(face1_path)
        validate_face_image(face2_path)

        # 初始化客户端
        client = FrsClient.new_builder() \
            .with_credentials(credentials) \
            .with_region(FrsRegion.value_of(REGION)) \
            .build()

        # 读取并编码图片
        def read_image(path):
            try:
                with open(path, "rb") as f:
                    return base64.b64encode(f.read()).decode()
            except Exception as e:
                raise IOError(f"读取图片失败: {str(e)}")

        img1 = read_image(face1_path)
        img2 = read_image(face2_path)

        # 构建请求
        request = CompareFaceByBase64Request()
        request.body = FaceCompareBase64Req(
            image1_base64=img1,
            image2_base64=img2
        )

        # 发送请求
        response = client.compare_face_by_base64(request)
        result = response.to_dict()

        # 解析结果
        similarity = result.get("similarity", 0)
        logger.info(f"人脸比对相似度: {similarity}")

        return similarity >= 0.85

    except exceptions.ClientRequestException as e:
        logger.error(f"华为云API错误: {e.error_code} - {e.error_msg}")
        raise Exception(f"服务暂时不可用（错误码：{e.error_code}）")
    except Exception as e:
        logger.error(f"人脸比对失败: {str(e)}")
        raise