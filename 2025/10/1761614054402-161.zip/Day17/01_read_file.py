"""
文件管理 - 文本文件读取

文件是计算机中存储数据的单位
    文本文件 : 字符  人类直接可读
    二进制文件: 二进制数据  人类不直接可读

"""
# 1.打开文件 (IO操作 输入输出)
file = open("test.py", 'r', encoding="utf-8")

# 2.读文件
# print(file.read())  # 读所有
# file.seek(0) #重置文件指针到开头(或指定位置)
# print(file.read(8))  # 指定字符数

# print(file.readline())  # 1行
# print(file.readlines())  # 所有内容 列表

# 大文件
for line in file:
    print(line)

# 3.关闭文件
file.close()

# 配合with使用 自动关闭资源
with open("test.py", 'r', encoding="utf-8") as file:
    print(file.read(10))









